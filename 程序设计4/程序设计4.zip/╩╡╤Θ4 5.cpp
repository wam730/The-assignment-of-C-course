#include<stdio.h>
#include<cstdlib>
{
	
	system("pause");
	return 0;
}