#include<stdio.h>
#include<cstdlib>
int main()
{
	int a[5][5]={{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,-15},{20,21,22,23,24},{16,17,18,19,25}},i,j,n=5,minrow=0,mincol=0;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("a[%d][%d]=%d\n",i,j,a[i][j]);
		}
	}
     for(i=0; i<5; i++)
	{
           for(j=0;j<5;j++)     
	     {
               if(a[i][j]<a[minrow][mincol])
                 { minrow = i;  mincol = j;   }
           }
	}
	printf("��Сֵ��:a[%d][%d]=%d", minrow,mincol, a[minrow][mincol]);
	system("pause");
	return 0;
}