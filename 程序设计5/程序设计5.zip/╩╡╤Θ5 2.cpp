#include<stdio.h>
#include<cstdlib>
#include<time.h>
int main()
{
	int i,j,p,flag,a[10],n=10,tmp;
    for(i = 0; i < n; i++)
	{
	a[i]=rand()%100;
	}
		for(i=0;i<n-1;i++)
    {
		for(j=0;j<n-i-1;j++)
		{
		      if (a[j]>a[j+1] )
		     {
			  tmp=a[j];
			  a[j]=a[j+1];
			  a[j+1]=tmp;
		     }
		}
	}
	printf("��%d�����������\n",n);
	for(i=0;i<=n-1;i++) 
		{
			printf("%4d ",a[i]);
		}
	printf("\n");	
	printf("������P��ֵ��");
	scanf("%d",&p);
	for(i=0;i<10;i++)
	{
		if(p==a[i])
			{
					for(j=i;j<9;j++)
				{
					a[j]=a[j+1];
				}
				flag=-1;
				break;
			}
		else if(p<a[i])
			{	
				for(j=10;j>i;j--)
				{	
					a[j]=a[j-1];		
				}
				a[i]=p;	flag=1;	break;
			}
		else if(i==10)
			{
				a[10]=p;	flag=1;
			}
	}
	for(i=0;i<10+flag;i++)
		{
			printf("%4d",a[i]);
		}
	system("pause");
	return 0;
}