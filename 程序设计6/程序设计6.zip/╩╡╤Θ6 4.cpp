#include<stdio.h>
#include<cstdlib>
int main()
{
	printf("����Ԥ������ľ������ת��:\n");
	void zhuanzhi();
	zhuanzhi();
	system("pause");
	return 0;
}
void zhuanzhi()
{
	int x[3][3]={1,2,3,4,5,6,7,8,9};
	int i,j,temp;
	for(i = 0;i < 3;i++)
	{
		for(j = 0; j < 3;j++)
		{
			if (j>i)
			{
				temp=x[i][j];
				x[i][j]=x[j][i];
				x[j][i]=temp;
			}
		}
	}
   for(i = 0;i < 3;i++)
	{
		for(j = 0; j < 3;j++)
		{
			printf("%d ",x[i][j]);
			
		}
			printf("\n");
   }
}


